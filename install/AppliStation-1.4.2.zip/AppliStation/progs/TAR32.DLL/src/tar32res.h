//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by tar32.rc
//
#define IDD_CONFIG                      102
#define IDD_DIALOG_STATUS               103
#define IDD_DIALOG_CONFIRM_OVERWRITE    104
#define IDD_CONFIRM_OVERWRITE           104
#define IDC_PROGRESS_FILE               1003
#define IDC_STATIC_FILENAME             1005
#define IDC_STATIC_PROGRESS             1006
#define IDC_BUTTON_OVERWRITE            1007
#define IDC_BUTTON_OVERWRITE_ALL        1008
#define IDC_EDIT_STATUS                 1010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
