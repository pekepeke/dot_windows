Requirements: Windows XP with a patched uxtheme.dll file.

An uxtheme patcher for SP2 can be found here:
http://www.softpedia.com/get/System/OS-Enhancements/Universal-UXTheme-Patcher.shtml
(if you use SP3 you'll need another one)

Doubleclick on the *.msstyles file to use the theme.
(If it doesn't work, I can't help you.)

Visit my gallery for more themes:
http://lassekongo83.deviantart.com
Or visit my FAQ if you need help:
http://lassekongo83.deviantart.com/journal/18586248/

